Thanks for downloading CraftIRC for hey0's server mod

If you want up-to-date instructions or just want to contribute feedback, visit the plugin thread
found at http://forum.hey0.net/viewtopic.php?id=44

I appreciate and do consider any suggestions I receive, as you can see from the ongoing discussion.

If you're interested in the source code, you can find it here http://github.com/Animosity/CraftIRC


Kind regards,

Animosity