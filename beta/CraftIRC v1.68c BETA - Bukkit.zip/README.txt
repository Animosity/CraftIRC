Thanks for downloading CraftIRC for Bukkit

If you want up-to-date instructions or just want to contribute feedback, visit the plugin thread
found at http://forums.bukkit.org/threads/craftirc.253/

Place CraftIRC.jar into your /plugins folder

Then place CraftIRC.settings into your main server folder, and edit the settings within.




-Animosity